prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20873491681539343017
,p_default_application_id=>104061
,p_default_id_offset=>0
,p_default_owner=>'RESEARCHPS'
);
wwv_flow_api.create_page(
 p_id=>7
,p_user_interface_id=>wwv_flow_api.id(21916062295509546448)
,p_name=>'chat'
,p_step_title=>'Chat'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''body'').on(''keydown'', ''input, select, textarea'', function(e){',
'    var self = $(this),',
'                form = self.parents(''form:eq(0)''),',
'        focusable,',
'        next;',
'    if(e.keyCode == 13){',
'        focusable = form.find(''input, a, select, button, textarea'').filter('':visible'');',
'        next = focusable.eq(focusable.index(this)+1);',
'        if(next.length){',
'            next.focus();',
'        }else{',
'            form.submit();',
'        }',
'        return false;',
'    }',
'});'))
,p_page_template_options=>'#DEFAULT#'
,p_overwrite_navigation_list=>'Y'
,p_last_updated_by=>'PRAJAKTA.SHIRKE@HARBINGERGROUP.COM'
,p_last_upd_yyyymmddhh24miss=>'20200218114118'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(25470017763170520405)
,p_plug_name=>'Chat'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(21914679043047546391)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(25470017853985520406)
,p_name=>'Chat View'
,p_parent_plug_id=>wwv_flow_api.id(25470017763170520405)
,p_template=>wwv_flow_api.id(21914679043047546391)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:i-h240:t-Region--removeHeader:t-Region--noBorder:t-Region--scrollBody:margin-left-none'
,p_component_template_options=>'#DEFAULT#:t-Report--staticRowColors:t-Report--rowHighlightOff:t-Report--noBorders'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Select decode(USER_NAME, ',
'              ''prajakta.shirke@harbingergroup.com'', ''<img src="#APP_IMAGES#bgImage.jpg" width=20 height=20 style="border-radius: 50%;></img>'' , ',
'              ''test@test.com'', ''<img src="#APP_IMAGES#harbingerLogo.jpeg" width=20 height=20 style="border-radius: 50%;></img>'',',
'             ''shirke@yopmail.com'', ''<img src="	#APP_IMAGES#logo.png" width=20 height=20 style="border-radius: 50%;></img>'')',
'             as USER_ICON,',
'        id as SL, ',
'        decode(USER_NAME, ',
'               ''prajakta.shirke@harbingergroup.com'', ''<font color = "black">''||MESSAGE||''</font>'', ',
'               ''test@test.com'', ''<font color="BLUE">''||MESSAGE||''</font>'',',
'              ''shirke@yopmail.com'', ''<font color="Green">''||MESSAGE||''</font>'') COMMENT_TEXT, USER_NAME',
'from hr_chat;'))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(25686120790496678509)
,p_query_num_rows=>100000
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(25470019662825520424)
,p_query_column_id=>1
,p_column_alias=>'USER_ICON'
,p_column_display_sequence=>1
,p_column_heading=>'User Icon'
,p_column_format=>'PCT_GRAPH:::'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(25470019315014520421)
,p_query_column_id=>2
,p_column_alias=>'SL'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(25470019416456520422)
,p_query_column_id=>3
,p_column_alias=>'COMMENT_TEXT'
,p_column_display_sequence=>4
,p_column_heading=>'Comment Text'
,p_column_format=>'PCT_GRAPH:::'
,p_column_alignment=>'CENTER'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(25470018289495520410)
,p_query_column_id=>4
,p_column_alias=>'USER_NAME'
,p_column_display_sequence=>3
,p_column_heading=>'User Name'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(25470018364454520411)
,p_plug_name=>'Text'
,p_parent_plug_id=>wwv_flow_api.id(25470017763170520405)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(21914679043047546391)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(25470020522783520433)
,p_name=>'user'
,p_parent_plug_id=>wwv_flow_api.id(25470017763170520405)
,p_template=>wwv_flow_api.id(21914679043047546391)
,p_display_sequence=>1
,p_region_template_options=>'#DEFAULT#:i-h240:t-Region--removeHeader:t-Region--noBorder:t-Region--hiddenOverflow:t-Form--noPadding:margin-bottom-none:margin-right-none'
,p_component_template_options=>'#DEFAULT#:t-Report--staticRowColors:t-Report--rowHighlightOff:t-Report--noBorders:t-Report--hideNoPagination'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'decode(lower(:app_user), ',
'              ''prajakta.shirke@harbingergroup.com'', ''<img src="#APP_IMAGES#bgImage.jpg" width=80 height=80 style="border-radius: 50%;></img>'' , ',
'              ''test@test.com'', ''<img src="#APP_IMAGES#harbingerLogo.jpeg" width=80 height=80 style="border-radius: 50%;></img>'',',
'             ''shirke@yopmail.com'', ''<img src="	#APP_IMAGES#logo.png" width=80 height=80 style="border-radius: 50%;></img>'')',
'             as USER_ICON, ',
'lower(:app_user) USER_NAME, ',
'''<img src= "#APP_IMAGES#Active/Active.png" width=20 height=20></img> Active'' Active',
'from dual'))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(25686120790496678509)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(26492130025130518708)
,p_query_column_id=>1
,p_column_alias=>'USER_ICON'
,p_column_display_sequence=>1
,p_column_heading=>'User Icon'
,p_column_format=>'PCT_GRAPH:::'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(25470020761696520435)
,p_query_column_id=>2
,p_column_alias=>'USER_NAME'
,p_column_display_sequence=>2
,p_column_heading=>'User Name'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(25470020810941520436)
,p_query_column_id=>3
,p_column_alias=>'ACTIVE'
,p_column_display_sequence=>3
,p_column_heading=>'Active'
,p_column_format=>'PCT_GRAPH:::'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(26492129538314518703)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(25470017763170520405)
,p_button_name=>'DELETE_CHAT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--danger'
,p_button_template_id=>wwv_flow_api.id(21916039790758546432)
,p_button_image_alt=>'Delete Chat'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-trash-o'
,p_security_scheme=>wwv_flow_api.id(21916066413875546464)
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(25470020049676520428)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(25470017763170520405)
,p_button_name=>'setting'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--warning'
,p_button_template_id=>wwv_flow_api.id(21916039790758546432)
,p_button_image_alt=>'Setting'
,p_button_position=>'BELOW_BOX'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(25470018495133520412)
,p_name=>'P7_TEXT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(25470018364454520411)
,p_prompt=>'Write Message'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(21916038694764546431)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(25470018630785520414)
,p_name=>'item'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P7_TEXT'
,p_bind_type=>'bind'
,p_bind_event_type=>'focusout'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(25470018774291520415)
,p_event_id=>wwv_flow_api.id(25470018630785520414)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P7_TEXT IS NOT NULL THEN',
'insert into hr_chat(message, id, user_name) values(:P7_TEXT, EMP_SEQ.nextval, lower(:app_user));',
'END IF;'))
,p_attribute_02=>'P7_TEXT'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(25470018921147520417)
,p_event_id=>wwv_flow_api.id(25470018630785520414)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P7_TEXT'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(26492129946980518707)
,p_event_id=>wwv_flow_api.id(25470018630785520414)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(25470017853985520406)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(25470020354827520431)
,p_name=>'setting'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(25470020049676520428)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(25470020444087520432)
,p_event_id=>wwv_flow_api.id(25470020354827520431)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.PLANETAPEX.CONTEXTUALTOOLBAR'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(25470020049676520428)
,p_attribute_01=>'STATIC'
,p_attribute_02=>'STATIC:fa-plane;1;Page 1,fa-car;f?p=&APP_ID.:2:&SESSION.;Page 2,fa-cog;alert("ola");Javascript Function'
,p_attribute_07=>'Info'
,p_attribute_09=>'top'
,p_attribute_11=>'standard'
,p_attribute_12=>'click'
,p_attribute_13=>'Y'
,p_attribute_15=>'click'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(26492129645318518704)
,p_name=>'New'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(26492129538314518703)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(25470018884309520416)
,p_event_id=>wwv_flow_api.id(26492129645318518704)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(25470017853985520406)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(26492129760472518705)
,p_event_id=>wwv_flow_api.id(26492129645318518704)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'delete from hr_chat;'
,p_wait_for_result=>'Y'
);
wwv_flow_api.component_end;
end;
/
