prompt --application/pages/page_00031
begin
--   Manifest
--     PAGE: 00031
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20873491681539343017
,p_default_application_id=>104061
,p_default_id_offset=>0
,p_default_owner=>'RESEARCHPS'
);
wwv_flow_api.create_page(
 p_id=>31
,p_user_interface_id=>wwv_flow_api.id(21916062295509546448)
,p_name=>'Chats'
,p_step_title=>'Chats'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''body'').on(''keydown'', ''input, select, textarea'', function(e){',
'    var self = $(this),',
'                form = self.parents(''form:eq(0)''),',
'        focusable,',
'        next;',
'    if(e.keyCode == 13){',
'        focusable = form.find(''input, a, select, button, textarea'').filter('':visible'');',
'        next = focusable.eq(focusable.index(this)+1);',
'        if(next.length){',
'            next.focus();',
'        }else{',
'            form.submit();',
'        }',
'        return false;',
'    }',
'});'))
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'PRAJAKTA.SHIRKE@HARBINGERGROUP.COM'
,p_last_upd_yyyymmddhh24miss=>'20200221070352'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(26935751121201837304)
,p_plug_name=>'User Chat'
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(21914679043047546391)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(26935753844732837331)
,p_name=>'Profile'
,p_parent_plug_id=>wwv_flow_api.id(26935751121201837304)
,p_template=>wwv_flow_api.id(21914679043047546391)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--noBorder:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--staticRowColors:t-Report--rowHighlightOff:t-Report--noBorders'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''<img src="#APP_IMAGES#harbingerLogo.jpeg" width=80 height=80 style="border-radius: 50%;></img>'' as icon,',
':P31_EMAIL, ''<img src= "#APP_IMAGES#Active/Active.png" width=20 height=20></img> Active'' as Active from dual;'))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(25686120790496678509)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(26935753977882837332)
,p_query_column_id=>1
,p_column_alias=>'ICON'
,p_column_display_sequence=>1
,p_column_heading=>'Icon'
,p_column_format=>'PCT_GRAPH:::'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(26935754062772837333)
,p_query_column_id=>2
,p_column_alias=>':P31_EMAIL'
,p_column_display_sequence=>2
,p_column_heading=>':p31 Email'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(26935754104602837334)
,p_query_column_id=>3
,p_column_alias=>'ACTIVE'
,p_column_display_sequence=>3
,p_column_heading=>'Active'
,p_column_format=>'PCT_GRAPH:::'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(26935754225792837335)
,p_plug_name=>'Text'
,p_parent_plug_id=>wwv_flow_api.id(26935751121201837304)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(21914679043047546391)
,p_plug_display_sequence=>2010
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(26941549198533018976)
,p_name=>'Chat'
,p_parent_plug_id=>wwv_flow_api.id(26935751121201837304)
,p_template=>wwv_flow_api.id(21914679043047546391)
,p_display_sequence=>2000
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--noBorder:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--staticRowColors:t-Report--rowHighlightOff:t-Report--noBorders'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       TO_USER,',
'       FROM_USER,',
'       MESSAGE,',
'       decode(FROM_USER, ',
'              lower(:app_user), ''<img src="#APP_IMAGES#bgImage.jpg" width=20 height=20 style="border-radius: 50%;></img>'' , ',
'              :P31_EMAIL , ''<img src="#APP_IMAGES#harbingerLogo.jpeg" width=20 height=20 style="border-radius: 50%;></img>'')',
'             as USER_ICON,',
'       TO_CHAR(created_date, ''MM/DD/YYYY HH24:MI:SS'') created_date',
'  from HR_USER_CHAT',
'  where (from_user = lower(:app_user) OR from_user = :P31_EMAIL) AND',
'  (to_user = :P31_EMAIL OR to_user = lower(:app_user))',
'   order by created_date asc;'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P31_TEXT'
,p_query_row_template=>wwv_flow_api.id(25686120790496678509)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Download'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(26941549574633018978)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(26941549911709018979)
,p_query_column_id=>2
,p_column_alias=>'TO_USER'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(26941550331420018979)
,p_query_column_id=>3
,p_column_alias=>'FROM_USER'
,p_column_display_sequence=>4
,p_column_heading=>'From User'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(26941550763914018979)
,p_query_column_id=>4
,p_column_alias=>'MESSAGE'
,p_column_display_sequence=>5
,p_column_heading=>'Message'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(26935755348444837346)
,p_query_column_id=>5
,p_column_alias=>'USER_ICON'
,p_column_display_sequence=>1
,p_column_heading=>'User Icon'
,p_column_format=>'PCT_GRAPH:::'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(27302054886642878501)
,p_query_column_id=>6
,p_column_alias=>'CREATED_DATE'
,p_column_display_sequence=>6
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(26935751293265837305)
,p_name=>'P31_EMAIL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(26935751121201837304)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(26935754303513837336)
,p_name=>'P31_TEXT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(26935754225792837335)
,p_prompt=>'Write your message!!'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(21916038694764546431)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(26935754419805837337)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(26935754225792837335)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(26935754539524837338)
,p_event_id=>wwv_flow_api.id(26935754419805837337)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(26941549198533018976)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(26935754667112837339)
,p_event_id=>wwv_flow_api.id(26935754419805837337)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P31_TEXT IS NOT NULL THEN',
'insert into hr_user_chat(from_user, to_user, id, message) values(lower(:app_user), :P31_EMAIL, EMP_SEQ.nextval,:P31_TEXT );',
'END IF;'))
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(26935754799572837340)
,p_event_id=>wwv_flow_api.id(26935754419805837337)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P31_TEXT'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(26935754822151837341)
,p_name=>'Text'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P31_TEXT'
,p_bind_type=>'bind'
,p_bind_event_type=>'focusout'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(26935755160632837344)
,p_event_id=>wwv_flow_api.id(26935754822151837341)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P31_TEXT IS NOT NULL THEN',
'insert into hr_user_chat(message, id, to_user, from_user) values(:P31_TEXT, EMP_SEQ.nextval, :P31_EMAIL, lower(:app_user));',
'END IF;'))
,p_attribute_02=>'P31_TEXT'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(26935754911576837342)
,p_event_id=>wwv_flow_api.id(26935754822151837341)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(26941549198533018976)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(26935755013572837343)
,p_event_id=>wwv_flow_api.id(26935754822151837341)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P31_TEXT'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(27302054922934878502)
,p_name=>'Refresh after few min'
,p_event_sequence=>30
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(26941549198533018976)
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(27302055069390878503)
,p_event_id=>wwv_flow_api.id(27302054922934878502)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(26941549198533018976)
);
wwv_flow_api.component_end;
end;
/
