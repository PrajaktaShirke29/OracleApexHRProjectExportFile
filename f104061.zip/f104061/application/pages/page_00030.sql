prompt --application/pages/page_00030
begin
--   Manifest
--     PAGE: 00030
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20873491681539343017
,p_default_application_id=>104061
,p_default_id_offset=>0
,p_default_owner=>'RESEARCHPS'
);
wwv_flow_api.create_page(
 p_id=>30
,p_user_interface_id=>wwv_flow_api.id(21916062295509546448)
,p_name=>'UserChat'
,p_step_title=>'UserChat'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'PRAJAKTA.SHIRKE@HARBINGERGROUP.COM'
,p_last_upd_yyyymmddhh24miss=>'20200226043553'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(26946663450641305664)
,p_plug_name=>'UserChat'
,p_region_template_options=>'#DEFAULT#:t-Region--noBorder:t-Region--scrollBody:margin-top-none'
,p_plug_template=>wwv_flow_api.id(21914679043047546391)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>'select email from(select email from hr_employees UNION select email from hr_managers)'
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(26946666114917305667)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(26946663450641305664)
,p_button_name=>'CHAT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--noUI'
,p_button_template_id=>wwv_flow_api.id(21916039790758546432)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Chat'
,p_button_position=>'BODY'
,p_button_redirect_url=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.:RP,31:P31_EMAIL:&P30_EMAIL.'
,p_button_condition=>'P30_EMAIL'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_grid_new_row=>'Y'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(26946663886756305664)
,p_name=>'P30_EMAIL'
,p_source_data_type=>'VARCHAR2'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(26946663450641305664)
,p_item_source_plug_id=>wwv_flow_api.id(26946663450641305664)
,p_prompt=>'select user you want to send message...'
,p_source=>'EMAIL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'HR_EMAILS.EMPMGR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select email r, email d from (select email from hr_employees ',
'UNION',
'select email from hr_managers) where email NOT IN (lower(:app_user));'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(21916038694764546431)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_protection_level=>'S'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(26946666975734305668)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(26946663450641305664)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form UserChat'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(26946666503537305667)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(26946663450641305664)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form UserChat'
);
wwv_flow_api.component_end;
end;
/
