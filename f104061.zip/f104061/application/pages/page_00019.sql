prompt --application/pages/page_00019
begin
--   Manifest
--     PAGE: 00019
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20873491681539343017
,p_default_application_id=>104061
,p_default_id_offset=>0
,p_default_owner=>'RESEARCHPS'
);
wwv_flow_api.create_page(
 p_id=>19
,p_user_interface_id=>wwv_flow_api.id(21916062295509546448)
,p_name=>'Upload Image'
,p_step_title=>'Upload Image'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'PRAJAKTA.SHIRKE@HARBINGERGROUP.COM'
,p_last_upd_yyyymmddhh24miss=>'20200131082556'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(22859455329708992208)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(21914677112392546389)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "ID","IMAGE_NAME","FILENAME","MIME_TYPE","DOC_SIZE","CHARSET","LAST_UPDATE_DATE",',
'sys.dbms_lob.getlength("CONTENT")"CONTENT", ',
'decode(nvl(sys.dbms_lob.getlength("CONTENT"),0),',
'                0,',
'                null,',
'                ''<img src="''||apex_util.get_blob_file_src(''P20_FILE_BROWSER'',ID)||''" height="75" width="75" />''            ',
'            )  Image',
'from "MYIMAGES_TBL"',
'',
'/*select ID,IMAGE_NAME,FILENAME,MIME_TYPE,',
'            decode(nvl(sys.dbms_lob.getlength(CONTENT),0),',
'                0,',
'                null,',
'                ''<img src="''||apex_util.get_blob_file_src(''P4_CONTENT'',id)||''" height="75" width="75" />''',
'                ',
'            )  Image,',
'            ''<a href="''||apex_util.get_blob_file_src(''P4_CONTENT'',id)||''">''||''Download''||''</a>'' Download',
'from MYIMAGES_TBL*/',
'',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(22859455745742992208)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.:RP:P20_ID:\#ID#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'PRAJAKTA.SHIRKE@HARBINGERGROUP.COM'
,p_internal_uid=>22859455745742992208
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22859455860306992208)
,p_db_column_name=>'ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22859456253071992211)
,p_db_column_name=>'IMAGE_NAME'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Image Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22859456608990992211)
,p_db_column_name=>'FILENAME'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Filename'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22859457026133992211)
,p_db_column_name=>'MIME_TYPE'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Mime Type'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20893551822160842919)
,p_db_column_name=>'DOC_SIZE'
,p_display_order=>14
,p_column_identifier=>'K'
,p_column_label=>'Doc Size'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20893551939738842920)
,p_db_column_name=>'CHARSET'
,p_display_order=>24
,p_column_identifier=>'L'
,p_column_label=>'Charset'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20893552074797842921)
,p_db_column_name=>'LAST_UPDATE_DATE'
,p_display_order=>34
,p_column_identifier=>'M'
,p_column_label=>'Last Update Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20893552195590842922)
,p_db_column_name=>'CONTENT'
,p_display_order=>44
,p_column_identifier=>'N'
,p_column_label=>'Content'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'DOWNLOAD:MYIMAGES_TBL:CONTENT:ID::::::attachment::'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20893552275736842923)
,p_db_column_name=>'IMAGE'
,p_display_order=>54
,p_column_identifier=>'O'
,p_column_label=>'Image'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_format_mask=>'PCT_GRAPH:::'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(22859461103528994667)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'228594612'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID_NAME:FILENAME:MIME_TYPE:DOC_SIZE:CHARSET:LAST_UPDATE_DATE:CONTENT:IMAGE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(22859459888955992214)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(22859455329708992208)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(21916039790758546432)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.:20'
);
wwv_flow_api.component_end;
end;
/
