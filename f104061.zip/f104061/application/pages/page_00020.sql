prompt --application/pages/page_00020
begin
--   Manifest
--     PAGE: 00020
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20873491681539343017
,p_default_application_id=>104061
,p_default_id_offset=>0
,p_default_owner=>'RESEARCHPS'
);
wwv_flow_api.create_page(
 p_id=>20
,p_user_interface_id=>wwv_flow_api.id(21916062295509546448)
,p_name=>'Upload Image'
,p_step_title=>'Upload Image'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function readURL(input) {  ',
'    if (input.files &&  ',
'        input.files[0] &&  ',
'        input.files[0].type.match(''image.*'')) {  ',
'        var reader = new FileReader();  ',
'  ',
'        reader.onload = function (e) {  ',
'            $(''#P20_IMAGE'').attr(''src'', e.target.result);  ',
'        }  ',
'  ',
'        try {  ',
'            reader.readAsDataURL(input.files[0]);  ',
'        }  ',
'        catch(err) {  ',
'            alert("error: " + err.message);  ',
'        }   ',
'    }  ',
'}  ',
'  ',
'$("#P20_FILE_BROWSER").change(function(){  ',
'    readURL(this);  ',
'});  '))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'PRAJAKTA.SHIRKE@HARBINGERGROUP.COM'
,p_last_upd_yyyymmddhh24miss=>'20200203093751'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(22859446045798992188)
,p_plug_name=>'Upload Image'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(21914679043047546391)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'MYIMAGES_TBL'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(22859453192980992205)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(22859446045798992188)
,p_button_name=>'Update'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(21916039790758546432)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_button_condition=>'P20_MGR_EMP_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(22859451939984992204)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(22859446045798992188)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(21916039790758546432)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(20893551415262842915)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(22859446045798992188)
,p_button_name=>'Upload'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--primary'
,p_button_template_id=>wwv_flow_api.id(21916039790758546432)
,p_button_image_alt=>'Upload'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(22859452760305992205)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(22859446045798992188)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(21916039790758546432)
,p_button_image_alt=>'Delete'
,p_button_position=>'REGION_TEMPLATE_DELETE'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P20_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(22859453822696992205)
,p_branch_name=>'Go To Page 1'
,p_branch_action=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22859446476674992188)
,p_name=>'P20_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(22859446045798992188)
,p_item_source_plug_id=>wwv_flow_api.id(22859446045798992188)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22859446836560992192)
,p_name=>'P20_IMAGE_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(22859446045798992188)
,p_item_source_plug_id=>wwv_flow_api.id(22859446045798992188)
,p_prompt=>'IMAGE NAME'
,p_source=>'IMAGE_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(21916038694764546431)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22859447194217992200)
,p_name=>'P20_FILENAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(22859446045798992188)
,p_item_source_plug_id=>wwv_flow_api.id(22859446045798992188)
,p_source=>'FILENAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22859447599357992200)
,p_name=>'P20_MIME_TYPE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(22859446045798992188)
,p_item_source_plug_id=>wwv_flow_api.id(22859446045798992188)
,p_source=>'MIME_TYPE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22859447912404992200)
,p_name=>'P20_DOC_SIZE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(22859446045798992188)
,p_item_source_plug_id=>wwv_flow_api.id(22859446045798992188)
,p_source=>'DOC_SIZE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22859448317327992201)
,p_name=>'P20_CHARSET'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(22859446045798992188)
,p_item_source_plug_id=>wwv_flow_api.id(22859446045798992188)
,p_source=>'CHARSET'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22859448729594992201)
,p_name=>'P20_LAST_UPDATE_DATE'
,p_source_data_type=>'DATE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(22859446045798992188)
,p_item_source_plug_id=>wwv_flow_api.id(22859446045798992188)
,p_source=>'LAST_UPDATE_DATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22859449150398992202)
,p_name=>'P20_FILE_BROWSER'
,p_source_data_type=>'BLOB'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(22859446045798992188)
,p_item_source_plug_id=>wwv_flow_api.id(22859446045798992188)
,p_prompt=>'Pick an image file'
,p_source=>'CONTENT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>60
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(21916038694764546431)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(23259620183483573324)
,p_name=>'P20_MGR_EMP_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(22859446045798992188)
,p_item_source_plug_id=>wwv_flow_api.id(22859446045798992188)
,p_source=>'MGR_EMP_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(20893551249005842913)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P20_FILE_BROWSER'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(20893551331689842914)
,p_event_id=>wwv_flow_api.id(20893551249005842913)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P20_IMAGE'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let filename = $v(''P20_FILE_BROWSER'').split(''\\'').pop().split(''/'').pop();  ',
'',
'$s("P20_FILENAME",filename); '))
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(22859454327416992206)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(22859446045798992188)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Upload Image'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(22859454716531992206)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Process form Upload Image'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  doc_size integer;  ',
'  Upload_blob blob; ',
'begin  ',
'',
'   --Copy BLOB to Upload_blob variable  ',
'   select blob_content  ',
'   into   Upload_blob  ',
'   from   APEX_APPLICATION_TEMP_FILES  ',
'   where  name = :P20_FILE_BROWSER;  ',
'  ',
'   --Get BLOB size  ',
'   doc_size := dbms_lob.getlength(Upload_blob);  ',
'--Copy data to table MyIMAGES_TBL  ',
'if doc_size <= 1000000 then  ',
'   insert into MyIMAGES_TBL (  ',
'          IMAGE_NAME, FILENAME,  ',
'          MIME_TYPE, DOC_SIZE,  ',
'          CONTENT, MGR_EMP_ID )  ',
'   select :P20_IMAGE_NAME, filename,  ',
'          mime_type, doc_size,  ',
'          blob_content, :P20_MGR_EMP_ID',
'   from   APEX_APPLICATION_TEMP_FILES  ',
'   where  name = :P20_FILE_BROWSER;  ',
'       ',
'   --Delete temp files    ',
'   delete from APEX_APPLICATION_TEMP_FILES where name = :P20_FILE_BROWSER;  ',
'else  ',
'   delete from APEX_APPLICATION_TEMP_FILES where name = :FILE_BROWSER;  ',
'   commit;  ',
'   raise_application_error(-20001,''Cannot upload pictures bigger than 1MB!'');  ',
'end if;  ',
'exception  ',
' when others then  ',
'     raise_application_error(-20001,''Error when uploading image!'');      ',
'end;  '))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(20893551415262842915)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(23259620385270573326)
,p_process_sequence=>20
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Apply change'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
'Begin ',
'    UPDATE MYIMAGES_TBL SET IMAGE_NAME = :P20_IMAGE_NAME, FILENAME = :P20_FILE_NAME, MIME_TYPE= :P20_MINE_TYPE,',
'    DOC_SIZE = :P20_DOC_SIZE, CONTENT =:P20_FILE_BROWSER',
'    WHERE MGR_EMP_ID =:P20_MGR_EMP_ID;',
'end;',
'*/',
'',
'declare',
'  doc_size integer;  ',
'  Upload_blob blob; ',
'begin  ',
'',
'   --Copy BLOB to Upload_blob variable  ',
'   select blob_content  ',
'   into   Upload_blob  ',
'   from   APEX_APPLICATION_TEMP_FILES  ',
'   where  name = :P20_FILE_BROWSER;  ',
'  ',
'   --Get BLOB size  ',
'   doc_size := dbms_lob.getlength(Upload_blob);  ',
'--Copy data to table MyIMAGES_TBL  ',
'if doc_size <= 1000000 then  ',
'       UPDATE MYIMAGES_TBL SET IMAGE_NAME = :P20_IMAGE_NAME, FILENAME = :P20_FILE_NAME, MIME_TYPE= :P20_MINE_TYPE,',
'    DOC_SIZE = doc_size, CONTENT = Upload_blob',
'    WHERE MGR_EMP_ID =:P20_MGR_EMP_ID;',
'       ',
'   --Delete temp files    ',
'   delete from APEX_APPLICATION_TEMP_FILES where name = :P20_FILE_BROWSER;  ',
'else  ',
'   delete from APEX_APPLICATION_TEMP_FILES where name = :FILE_BROWSER;  ',
'   commit;  ',
'   raise_application_error(-20001,''Cannot upload pictures bigger than 1MB!'');  ',
'end if;  ',
'exception  ',
' when others then  ',
'     raise_application_error(-20001,''Error when uploading image!'');      ',
'end;  '))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(22859453192980992205)
);
wwv_flow_api.component_end;
end;
/
