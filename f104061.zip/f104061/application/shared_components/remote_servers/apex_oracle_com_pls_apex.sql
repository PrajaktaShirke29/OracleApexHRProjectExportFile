prompt --application/shared_components/remote_servers/apex_oracle_com_pls_apex
begin
--   Manifest
--     REMOTE SERVER: apex-oracle-com-pls-apex
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20873491681539343017
,p_default_application_id=>104061
,p_default_id_offset=>0
,p_default_owner=>'RESEARCHPS'
);
wwv_flow_api.create_remote_server(
 p_id=>wwv_flow_api.id(24820689424174586807)
,p_name=>'apex-oracle-com-pls-apex'
,p_static_id=>'apex_oracle_com_pls_apex'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('apex_oracle_com_pls_apex'),'https://apex.oracle.com/pls/apex/')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('apex_oracle_com_pls_apex'),'')
,p_server_type=>'WEB_SERVICE'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('apex_oracle_com_pls_apex'),'')
,p_prompt_on_install=>false
);
wwv_flow_api.component_end;
end;
/
