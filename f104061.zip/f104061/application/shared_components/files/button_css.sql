prompt --application/shared_components/files/button_css
begin
--   Manifest
--     APP STATIC FILES: 104061
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20873491681539343017
,p_default_application_id=>104061
,p_default_id_offset=>0
,p_default_owner=>'RESEARCHPS'
);
wwv_flow_api.g_varchar2_table := wwv_flow_api.empty_varchar2_table;
wwv_flow_api.g_varchar2_table(1) := '2E627574746F6E2D7261647B0A09626F726465722D7261646975733A3530253B0A7D0A';
wwv_flow_api.create_app_static_file(
 p_id=>wwv_flow_api.id(27818121427307036106)
,p_file_name=>'button.css'
,p_mime_type=>'text/css'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_api.varchar2_to_blob(wwv_flow_api.g_varchar2_table)
);
wwv_flow_api.component_end;
end;
/
