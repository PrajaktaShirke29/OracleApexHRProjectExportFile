prompt --application/shared_components/plugins/dynamic_action/timer
begin
--   Manifest
--     PLUGIN: TIMER
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20873491681539343017
,p_default_application_id=>104061
,p_default_id_offset=>0
,p_default_owner=>'RESEARCHPS'
);
wwv_flow_api.create_plugin(
 p_id=>wwv_flow_api.id(25649378270208761697)
,p_plugin_type=>'DYNAMIC ACTION'
,p_name=>'TIMER'
,p_display_name=>'Timer'
,p_category=>'COMPONENT'
,p_supported_ui_types=>'DESKTOP:JQM_SMARTPHONE'
,p_image_prefix => nvl(wwv_flow_application_install.get_static_plugin_file_prefix('DYNAMIC ACTION','TIMER'),'')
,p_api_version=>2
,p_substitute_attributes=>true
,p_subscribe_plugin_settings=>true
,p_version_identifier=>'1.0'
);
wwv_flow_api.component_end;
end;
/
