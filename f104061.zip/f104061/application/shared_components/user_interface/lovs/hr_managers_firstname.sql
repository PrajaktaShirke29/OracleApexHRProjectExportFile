prompt --application/shared_components/user_interface/lovs/hr_managers_firstname
begin
--   Manifest
--     HR_MANAGERS.FIRSTNAME
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20873491681539343017
,p_default_application_id=>104061
,p_default_id_offset=>0
,p_default_owner=>'RESEARCHPS'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(21916122827944546703)
,p_lov_name=>'HR_MANAGERS.FIRSTNAME'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'HR_MANAGERS'
,p_return_column_name=>'ID'
,p_display_column_name=>'FIRSTNAME'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'FIRSTNAME'
,p_default_sort_direction=>'ASC'
);
wwv_flow_api.component_end;
end;
/
