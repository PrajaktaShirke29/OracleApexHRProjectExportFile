prompt --application/shared_components/user_interface/lovs/hr_emails_empmgr
begin
--   Manifest
--     HR_EMAILS.EMPMGR
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20873491681539343017
,p_default_application_id=>104061
,p_default_id_offset=>0
,p_default_owner=>'RESEARCHPS'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(26735113515490036069)
,p_lov_name=>'HR_EMAILS.EMPMGR'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select email r, email d from (select email from hr_employees ',
'UNION',
'select email from hr_managers) where email NOT IN (lower(:app_user));'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
);
wwv_flow_api.component_end;
end;
/
