prompt --application/shared_components/user_interface/lovs/hr_employees_firstname
begin
--   Manifest
--     HR_EMPLOYEES.FIRSTNAME
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20873491681539343017
,p_default_application_id=>104061
,p_default_id_offset=>0
,p_default_owner=>'RESEARCHPS'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(21916122223147546702)
,p_lov_name=>'HR_EMPLOYEES.FIRSTNAME'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Select e.firstname d , E.id r ',
'from HR_EMPLOYEES E INNER JOIN HR_EMP_MGR EM ON E.ID = EM.HR_EMPLOYEES_ID INNER JOIN HR_MANAGERS M ON M.ID=EM.HR_MANAGERS_ID',
'where m.id = :P11_HR_MANAGERS_ID OR m.id = :P9_HR_MANAGERS_ID OR m.id = :P13_HR_MANAGERS_ID OR m.id = :P29_HR_MANAGERS_ID OR e.id = (select id from HR_employees)',
''))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_query_table=>'HR_EMPLOYEES'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
);
wwv_flow_api.component_end;
end;
/
