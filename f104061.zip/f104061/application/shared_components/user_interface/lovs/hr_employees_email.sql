prompt --application/shared_components/user_interface/lovs/hr_employees_email
begin
--   Manifest
--     HR_EMPLOYEES.EMAIL
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20873491681539343017
,p_default_application_id=>104061
,p_default_id_offset=>0
,p_default_owner=>'RESEARCHPS'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(24061592517763937442)
,p_lov_name=>'HR_EMPLOYEES.EMAIL'
,p_lov_query=>'select email d, email r from hr_employees where id = :HR_EMPLOYEES_ID OR id = :P11_HR_EMPLOYEES_ID OR id = :P9_HR_EMPLOYEES_ID OR id = :P13_HR_EMPLOYEES_ID  OR id = :P29_HR_EMPLOYEES_ID;'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_query_table=>'HR_EMPLOYEES'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
);
wwv_flow_api.component_end;
end;
/
